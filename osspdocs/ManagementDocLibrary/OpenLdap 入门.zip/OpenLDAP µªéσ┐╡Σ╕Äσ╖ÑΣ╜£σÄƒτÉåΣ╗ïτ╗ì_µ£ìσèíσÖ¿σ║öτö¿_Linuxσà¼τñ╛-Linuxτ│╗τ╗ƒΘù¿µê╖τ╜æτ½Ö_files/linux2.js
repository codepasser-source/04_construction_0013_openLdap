document.writeln("<script async src=\'//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\'></script>");
document.writeln("<!-- Linux��������ҳ���300x250, ������ 09-12-6 -->");
document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:inline-block;width:300px;height:250px\'");
document.writeln("     data-ad-client=\'ca-pub-5195587195407606\'");
document.writeln("     data-ad-slot=\'6879159141\'></ins>");
document.writeln("<script>");
document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
document.writeln("</script>");