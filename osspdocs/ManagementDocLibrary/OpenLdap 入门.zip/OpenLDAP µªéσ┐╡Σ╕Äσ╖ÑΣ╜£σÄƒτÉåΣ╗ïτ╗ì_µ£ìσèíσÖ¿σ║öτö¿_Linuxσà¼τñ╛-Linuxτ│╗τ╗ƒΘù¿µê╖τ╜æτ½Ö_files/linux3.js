document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
document.writeln("<ins class=\"adsbygoogle\"");
document.writeln("     style=\"display:block; text-align:center;\"");
document.writeln("     data-ad-format=\"fluid\"");
document.writeln("     data-ad-layout=\"in-article\"");
document.writeln("     data-ad-client=\"ca-pub-5195587195407606\"");
document.writeln("     data-ad-slot=\"8123243321\"><\/ins>");
document.writeln("<script>");
document.writeln("     (adsbygoogle = window.adsbygoogle || []).push({});");
document.writeln("<\/script>")