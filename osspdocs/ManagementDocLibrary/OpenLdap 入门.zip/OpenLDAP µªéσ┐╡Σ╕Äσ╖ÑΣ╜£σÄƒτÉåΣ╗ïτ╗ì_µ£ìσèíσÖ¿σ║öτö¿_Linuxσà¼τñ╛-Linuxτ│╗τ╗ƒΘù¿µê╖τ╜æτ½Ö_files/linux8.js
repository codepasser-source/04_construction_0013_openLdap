﻿document.writeln("<script async src=\"\/\/pagead2.googlesyndication.com\/pagead\/js\/adsbygoogle.js\"><\/script>");
document.writeln("<!-- Google匹配内容 -->");
document.writeln("<ins class=\"adsbygoogle\"");
document.writeln("     style=\"display:inline-block;width:760px;height:410px\"");
document.writeln("     data-ad-client=\"ca-pub-5195587195407606\"");
document.writeln("     data-ad-slot=\"7446930524\"><\/ins>");
document.writeln("<script>");
document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
document.writeln("<\/script>")